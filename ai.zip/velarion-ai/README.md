# VELARION AI — Netlify starter

Premium dark/purple AI workspace starter built with Next.js, Supabase Auth, and Gemini API. Supabase authentication is optional for preview: without Supabase, visitors can open the workspace in Guest Preview mode. Real account login and real AI requests require server configuration.

## Included
- Responsive landing page and animated orb identity
- Supabase email/password signup and login
- Protected dashboard (session checked before rendering workspace)
- Server-side AI endpoint that validates the Supabase access token
- Gemini provider integration; API key stays server-side
- Netlify Next.js adapter configuration
- Optional SQL schema with per-user Row Level Security for chat history (persistence UI is a future milestone)

## 1. Create Supabase project
1. Create a project at https://supabase.com.
2. In Project Settings → API, copy Project URL and anon/public key (or publishable key supported by your Supabase project).
3. In Authentication → URL Configuration, set Site URL to your Netlify site URL after deployment. Add `https://YOUR-SITE.netlify.app/**` to Redirect URLs if you enable email confirmation.
4. In Authentication → Providers, ensure Email is enabled.

## 2. Get an AI API key
Create a Gemini API key at https://aistudio.google.com/app/apikey. Review current model availability, free-tier quotas, and regional terms in Google AI Studio before use. Free quotas and model availability can change; this project does not guarantee unlimited free inference.

## 3. Configure locally
```bash
cp .env.example .env.local
# Fill in the three values
npm install
npm run dev
```
Open http://localhost:3000.

## 4. Deploy to Netlify
1. Push this project to a GitHub repository.
2. In Netlify choose Add new site → Import an existing project and select the repository.
3. Build command: `npm run build`. The included `netlify.toml` configures the Next.js adapter.
4. In Site configuration → Environment variables add:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `GEMINI_API_KEY`
   - optional `GEMINI_MODEL` (default `gemini-2.5-flash`)
5. Deploy / trigger a new deploy after adding variables.

Do not commit `.env.local` or put the Gemini key in a `NEXT_PUBLIC_` variable. Use only Supabase anon/publishable key in the browser; never expose the service-role key.

## Current limitations / next milestones
- AI chat currently sends one prompt per request; conversation context is not yet threaded into subsequent Gemini requests.
- Chat messages are currently held in browser state. Run `supabase/schema.sql` to prepare private chat-history tables; persistence and history UI need to be wired in a follow-up milestone.
- Image/video generation, voice, web search, file analysis, usage metering, moderation, and billing are not implemented yet. The landing page presents these as planned workspace areas, not active generators.
- Add rate limiting and usage quotas before opening the service to the public. A client-side free label is not a quota enforcement mechanism.
- For production, configure Supabase email confirmation, CAPTCHA/abuse protection, monitoring, backups, and provider spend limits.

## Mobile later
The same responsive web app can be packaged later with Capacitor for Android and iOS. Store publication still requires store developer accounts, platform-specific testing, privacy disclosures, and review approval.

## Multi-provider AI integration

The authenticated `/api/chat` route supports these text providers: Gemini, Groq, OpenRouter, OpenAI, Claude (Anthropic), and Perplexity. The dashboard model selector lets a signed-in user choose the chat provider. Set the matching server-only environment variable in Netlify; providers without a key remain unavailable and return a clear setup message. The user must be authenticated with Supabase before the route calls any provider.

### Netlify environment variables

See `.env.example` for the full list. Required for sign-in: `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY`. Add only the AI provider keys you have. Never prefix provider secrets with `NEXT_PUBLIC_`, commit real keys, or put them in browser/mobile code.

### Media provider status

`REPLICATE_API_TOKEN`, `FAL_KEY`, `RUNWAY_API_KEY`, `KLING_API_KEY`, `DEEPGRAM_API_KEY`, and `ELEVENLABS_API_KEY` are reserved server-side configuration for the image, video, and audio feature routes. The current starter does **not** yet expose image/video/voice generation endpoints or controls; those require dedicated async job handling, upload/storage, status polling/webhooks, and provider-specific payloads. Do not advertise those tools as active until those routes are implemented and tested.

### Provider notes

- Gemini, Groq, OpenRouter, OpenAI, and Perplexity use OpenAI-compatible chat-completions payloads in this starter (Gemini's OpenAI-compatible endpoint).
- Claude uses Anthropic's native Messages API.
- Model IDs are configurable through the corresponding `*_MODEL` variables. Verify model availability and account access in each provider console.
- Provider usage may incur charges and free-tier limits vary. “Free workspace” is an application access policy, not a guarantee that upstream inference is free.


## Guest Preview mode
If Supabase environment variables are not configured, Login and Signup route to the workspace in Guest Preview mode instead of showing a Supabase configuration error. Guest Preview is for testing the interface only; it does not provide real AI inference or account persistence. To enable real accounts and AI chat, configure Supabase URL + anon/publishable key and at least one server-side AI provider key in Netlify.

Never put provider secrets in `NEXT_PUBLIC_` variables or commit real credentials.


## Gemini + Groq (Guest mode supported)
For real AI chat without Supabase, add `GEMINI_API_KEY` and `GROQ_API_KEY` in Netlify Site configuration → Environment variables, then redeploy. Gemini is the default provider and Groq is used automatically if Gemini is unavailable. Selecting Groq makes Groq primary and Gemini fallback. Supabase remains optional; if Supabase is configured, authenticated sessions are still required.

Keep both provider keys server-side only. Do not use `NEXT_PUBLIC_` prefixes for provider secrets.


## Deploy to Vercel
This project uses Next.js and is prepared for Vercel. Import the repository in Vercel or upload the project through a supported Git workflow. Use the project root (`velarion-ai`) as the Root Directory if the repository contains a parent folder. Vercel should detect Next.js automatically.

Configure server-side environment variables in Vercel Project Settings → Environment Variables:
- `GEMINI_API_KEY`
- `GROQ_API_KEY`
- `NEXT_PUBLIC_SUPABASE_URL` (optional for Guest Preview; required for authenticated accounts)
- `NEXT_PUBLIC_SUPABASE_ANON_KEY` (optional for Guest Preview; required for authenticated accounts)

Optional provider model overrides:
- `GEMINI_MODEL=gemini-2.5-flash`
- `GROQ_MODEL=llama-3.3-70b-versatile`

After changing environment variables, redeploy. Never expose provider API keys in client-side code or `NEXT_PUBLIC_` variables.
