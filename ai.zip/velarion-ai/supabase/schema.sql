-- Optional chat history schema for the next development milestone.
-- Run this in Supabase SQL Editor. Row Level Security keeps each user's rows private.
create table if not exists public.chat_sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null default 'Percakapan baru',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists public.chat_messages (
  id uuid primary key default gen_random_uuid(),
  session_id uuid not null references public.chat_sessions(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('user','assistant')),
  content text not null,
  created_at timestamptz not null default now()
);
alter table public.chat_sessions enable row level security;
alter table public.chat_messages enable row level security;
drop policy if exists "Users manage own sessions" on public.chat_sessions;
create policy "Users manage own sessions" on public.chat_sessions for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
drop policy if exists "Users manage own messages" on public.chat_messages;
create policy "Users manage own messages" on public.chat_messages for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create index if not exists chat_sessions_user_updated on public.chat_sessions(user_id, updated_at desc);
create index if not exists chat_messages_session_created on public.chat_messages(session_id, created_at);
