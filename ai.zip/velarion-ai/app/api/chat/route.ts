import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';

export const runtime = 'nodejs';

const SYSTEM = 'Kamu adalah Velarion AI, asisten yang ramah, cerdas, jujur, dan membantu. Jawab dalam bahasa yang digunakan pengguna. Untuk kode, berikan solusi yang jelas dan terstruktur. Jangan mengaku memiliki akses web, file, atau fitur yang tidak tersedia.';

type Provider = 'gemini' | 'groq';
const CONFIG: Record<Provider, { env: string; base: string; model: string; label: string }> = {
  gemini: {
    env: 'GEMINI_API_KEY',
    base: 'https://generativelanguage.googleapis.com/v1beta/openai/chat/completions',
    model: process.env.GEMINI_MODEL || 'gemini-2.5-flash',
    label: 'Google Gemini',
  },
  groq: {
    env: 'GROQ_API_KEY',
    base: 'https://api.groq.com/openai/v1/chat/completions',
    model: process.env.GROQ_MODEL || 'llama-3.3-70b-versatile',
    label: 'Groq',
  },
};

async function callProvider(provider: Provider, message: string, requestedModel?: string) {
  const config = CONFIG[provider];
  const key = process.env[config.env];
  if (!key) throw new Error(`${config.label} belum dikonfigurasi di Netlify (${config.env}).`);

  const model = requestedModel && provider === 'gemini' && requestedModel.startsWith('gemini-')
    ? requestedModel
    : requestedModel && provider === 'groq' && requestedModel.startsWith('llama-')
      ? requestedModel
      : config.model;

  const response = await fetch(config.base, {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      authorization: `Bearer ${key}`,
    },
    body: JSON.stringify({
      model,
      messages: [
        { role: 'system', content: SYSTEM },
        { role: 'user', content: message },
      ],
      temperature: 0.7,
      max_tokens: 2048,
    }),
    signal: AbortSignal.timeout(45000),
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const detail = data?.error?.message || data?.message || `${config.label} gagal (${response.status}).`;
    throw new Error(detail);
  }

  const reply = data?.choices?.[0]?.message?.content?.trim();
  if (!reply) throw new Error(`${config.label} tidak mengembalikan jawaban.`);
  return { reply, provider, model };
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const message = body?.message;
    const requested = String(body?.provider || 'gemini').toLowerCase() as Provider;

    if (typeof message !== 'string' || !message.trim()) {
      return NextResponse.json({ error: 'Pesan tidak boleh kosong.' }, { status: 400 });
    }
    if (message.length > 12000) {
      return NextResponse.json({ error: 'Pesan terlalu panjang (maksimal 12.000 karakter).' }, { status: 413 });
    }
    if (!(requested in CONFIG)) {
      return NextResponse.json({ error: 'Pilih Gemini atau Groq.' }, { status: 400 });
    }

    // Supabase is optional. If it is configured, preserve account-session protection.
    const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
    const anon = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
    if (url && anon) {
      const token = req.headers.get('authorization')?.replace(/^Bearer\s+/i, '') || '';
      if (!token) return NextResponse.json({ error: 'Sesi login diperlukan.' }, { status: 401 });
      const supabase = createClient(url, anon, { auth: { persistSession: false } });
      const { data: { user }, error } = await supabase.auth.getUser(token);
      if (error || !user) return NextResponse.json({ error: 'Sesi login tidak valid. Silakan masuk kembali.' }, { status: 401 });
    }

    // Selected provider is primary; the other provider is automatic fallback.
    const order: Provider[] = requested === 'gemini' ? ['gemini', 'groq'] : ['groq', 'gemini'];
    const failures: string[] = [];
    for (const provider of order) {
      if (!process.env[CONFIG[provider].env]) {
        failures.push(`${CONFIG[provider].label}: API key belum diisi`);
        continue;
      }
      try {
        const result = await callProvider(provider, message.trim(), typeof body?.model === 'string' ? body.model : undefined);
        return NextResponse.json({ ...result, fallbackUsed: provider !== requested });
      } catch (error) {
        failures.push(`${CONFIG[provider].label}: ${error instanceof Error ? error.message : 'gagal'}`);
      }
    }

    return NextResponse.json({
      error: `Gemini dan Groq belum bisa menjawab. ${failures.join(' | ')}`,
    }, { status: 503 });
  } catch (error) {
    const message = error instanceof Error && error.name === 'TimeoutError'
      ? 'Permintaan ke AI terlalu lama. Coba kirim ulang.'
      : 'Terjadi kesalahan pada server. Coba beberapa saat lagi.';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
