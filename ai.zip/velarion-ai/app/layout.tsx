import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = {
  title: 'Velarion AI — Beyond Intelligence',
  description: 'Your creative intelligence workspace. Chat, code, research and create with Velarion AI.'
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="id"><body>{children}</body></html>;
}
