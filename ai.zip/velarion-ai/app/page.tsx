import Link from 'next/link';
import { ArrowRight, AudioLines, Code2, Image, Search, ShieldCheck, Sparkles, Video } from 'lucide-react';

const tools = [
  { icon: Sparkles, title: 'AI Chat', desc: 'Teman berpikir untuk ide, pertanyaan, dan pekerjaan sehari-hari.' },
  { icon: Code2, title: 'Coding Assistant', desc: 'Bantu menulis, memahami, dan memperbaiki kode.' },
  { icon: Search, title: 'Web Research', desc: 'Riset dan susun informasi menjadi jawaban yang rapi.' },
  { icon: Image, title: 'Image Studio', desc: 'Ruang untuk fitur kreasi gambar pada pengembangan berikutnya.' },
  { icon: Video, title: 'Video Studio', desc: 'Rencanakan ide dan storyboard video.' },
  { icon: AudioLines, title: 'Voice', desc: 'Fondasi antarmuka untuk pengalaman suara.' }
];
export default function Home() {
  return <main className="landing">
    <nav className="topbar wrap"><Link href="/" className="brand"><span className="brand-mark">V</span> VELARION<span className="brand-ai">AI</span></Link><div className="navlinks"><a href="#features">Fitur</a><a href="#about">Tentang</a><Link className="nav-login" href="/login">Masuk</Link><Link className="btn btn-small" href="/signup">Mulai Gratis <ArrowRight size={15}/></Link></div></nav>
    <section className="hero wrap"><div className="hero-copy"><div className="eyebrow"><span className="pulse"/> YOUR INTELLIGENCE WORKSPACE</div><h1>Think beyond.<br/><span>Create without limits.</span></h1><p className="hero-sub">Satu ruang untuk bertanya, membangun, meneliti, dan mengembangkan ide. Kenali cara baru bekerja bersama AI.</p><div className="hero-actions"><Link className="btn" href="/signup">Mulai gratis <ArrowRight size={17}/></Link><Link className="btn btn-ghost" href="/login">Saya sudah punya akun</Link></div><div className="hero-note"><ShieldCheck size={15}/> Akun diperlukan untuk menggunakan AI · Gratis untuk memulai</div></div><div className="orb-stage"><div className="orb-halo halo-one"/><div className="orb-halo halo-two"/><div className="orb"><div className="orb-core"/><div className="orb-shine"/></div><div className="orbit orbit-a"/><div className="orbit orbit-b"/><div className="float-card card-top"><Sparkles size={15}/> Intelligence, in motion</div><div className="float-card card-bottom"><span className="pulse"/> Velarion is ready</div></div></section>
    <section className="feature-section wrap" id="features"><div className="section-kicker">ONE PLATFORM, MANY POSSIBILITIES</div><h2>Tools for your next big idea.</h2><p className="section-desc">Mulai dari percakapan sederhana hingga alur kerja kreatif yang lebih kompleks.</p><div className="feature-grid">{tools.map(({icon:Icon,title,desc})=><article className="feature-card" key={title}><div className="feature-icon"><Icon size={21}/></div><h3>{title}</h3><p>{desc}</p></article>)}</div></section>
    <section className="cta wrap" id="about"><div><div className="section-kicker">START YOUR JOURNEY</div><h2>Make room for<br/><span>what's next.</span></h2><p>Buat akun gratis dan mulai jelajahi Velarion AI.</p></div><Link className="btn" href="/signup">Buat akun gratis <ArrowRight size={17}/></Link></section>
    <footer className="footer wrap"><Link href="/" className="brand"><span className="brand-mark">V</span> VELARION<span className="brand-ai">AI</span></Link><span>© 2026 Velarion AI. Built for what’s next.</span></footer>
  </main>;
}
